-- ==========================================================
-- وين تلقاه؟ — قاعدة البيانات الكاملة v1.1 (نوفمبر 2026) — لا ترفع هذا الملف على GitHub، يُشغَّل في Supabase فقط
-- وين تلقاه؟ — قاعدة البيانات الكاملة (Supabase / PostgreSQL)
-- الصقه كامل في: Supabase → SQL Editor → New query → Run
-- آمن للتشغيل أكثر من مرة، ويحدّث قاعدتك الحالية بدون ما يمسح بياناتك
-- ==========================================================

-- 1) الجداول -------------------------------------------------
create table if not exists shops (
  id bigint generated always as identity primary key,
  owner uuid not null default auth.uid(),
  shop_name text not null check (char_length(shop_name) between 2 and 80),
  category text not null,
  phone text not null check (char_length(phone) between 9 and 20),
  city text not null,
  created_at timestamptz not null default now()
);
alter table shops add column if not exists approved boolean not null default false;
alter table shops add column if not exists paid_until timestamptz;
alter table shops add column if not exists lat double precision;
alter table shops add column if not exists lng double precision;
alter table shops add column if not exists address text check (char_length(address) <= 200);

create table if not exists requests (
  id bigint generated always as identity primary key,
  owner uuid not null default auth.uid(),
  customer_name text not null check (char_length(customer_name) between 1 and 60),
  item text not null check (char_length(item) between 2 and 500),
  category text not null,
  city text not null,
  status text not null default 'معلق' check (status in ('معلق','تم التوفير')),
  images text[] not null default '{}',
  created_at timestamptz not null default now()
);

create table if not exists request_contacts (
  request_id bigint primary key references requests(id) on delete cascade,
  owner uuid not null default auth.uid(),
  phone text not null check (char_length(phone) between 9 and 20)
);

create table if not exists offers (
  id bigint generated always as identity primary key,
  request_id bigint not null references requests(id) on delete cascade,
  shop_id bigint not null references shops(id) on delete cascade,
  owner uuid not null default auth.uid(),
  price numeric not null check (price >= 0),
  notes text check (char_length(notes) <= 200),
  created_at timestamptz not null default now(),
  unique (request_id, shop_id)
);

-- إعدادات التطبيق (سعر الاشتراك الشهري: 10 دينار كقيمة مبدئية)
create table if not exists settings (key text primary key, value text not null);
insert into settings (key, value) values ('sub_price', '10') on conflict (key) do nothing;

-- حسابات الإدارة
create table if not exists admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

-- 2) دوال الحماية --------------------------------------------
create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

drop trigger if exists shops_lock on shops;
drop function if exists shops_lock_approved();

-- التاجر ما يقدر يوافق على نفسه ولا يغيّر اشتراكه، فقط الإدارة
create or replace function shops_lock() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_admin() then return new; end if;
  if tg_op = 'INSERT' then
    new.approved := false; new.paid_until := null;
  else
    new.approved := old.approved; new.paid_until := old.paid_until; new.owner := old.owner;
  end if;
  return new;
end $$;

create trigger shops_lock before insert or update on shops
for each row execute function shops_lock();

-- 2ب) صلاحيات الوصول للجداول والدالة (ضرورية، وإلا يطلع permission denied) ---
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on table
  public.shops, public.requests, public.request_contacts,
  public.offers, public.settings, public.admins
  to authenticated;
grant usage, select on all sequences in schema public to authenticated;
grant execute on function public.is_admin() to authenticated;

-- 3) تفعيل RLS -----------------------------------------------
alter table shops enable row level security;
alter table requests enable row level security;
alter table request_contacts enable row level security;
alter table offers enable row level security;
alter table settings enable row level security;
alter table admins enable row level security;

-- 4) السياسات ------------------------------------------------
-- المحلات: الزبون يشوف المحلات النشطة (موافَق عليها + اشتراك ساري) فقط
drop policy if exists shops_read on shops;
drop policy if exists shops_insert on shops;
drop policy if exists shops_update on shops;
drop policy if exists shops_delete on shops;
create policy shops_read on shops for select to authenticated
  using ((approved and paid_until > now()) or owner = auth.uid() or public.is_admin());
create policy shops_insert on shops for insert to authenticated
  with check (owner = auth.uid());
create policy shops_update on shops for update to authenticated
  using (owner = auth.uid() or public.is_admin())
  with check (owner = auth.uid() or public.is_admin());
create policy shops_delete on shops for delete to authenticated
  using (owner = auth.uid() or public.is_admin());

-- الطلبات (خاصة)
drop policy if exists req_read on requests;
drop policy if exists req_insert on requests;
drop policy if exists req_update on requests;
drop policy if exists req_delete on requests;
-- الطلب يشوفه صاحبه + المحلات النشطة في نفس مدينته وتخصصه + الإدارة (مو العامة)
create policy req_read on requests for select to authenticated using (
  owner = auth.uid() or public.is_admin() or exists (
    select 1 from shops s
    where s.owner = auth.uid() and s.approved and s.paid_until > now()
      and s.category = requests.category and s.city = requests.city)
);
create policy req_insert on requests for insert to authenticated with check (owner = auth.uid());
create policy req_update on requests for update to authenticated
  using (owner = auth.uid()) with check (owner = auth.uid());
create policy req_delete on requests for delete to authenticated using (owner = auth.uid() or public.is_admin());

-- رقم الزبون: لصاحب الطلب + المحل النشط اللي قدّم عرض + الإدارة
drop policy if exists contact_read on request_contacts;
drop policy if exists contact_insert on request_contacts;
create policy contact_read on request_contacts for select to authenticated using (
  owner = auth.uid() or public.is_admin() or exists (
    select 1 from offers o join shops s on s.id = o.shop_id
    where o.request_id = request_contacts.request_id
      and s.owner = auth.uid() and s.approved and s.paid_until > now())
);
create policy contact_insert on request_contacts for insert to authenticated
  with check (owner = auth.uid());

-- العروض: من محل نشط فقط، ويشوفها صاحب الطلب وصاحب المحل والإدارة
drop policy if exists offer_read on offers;
drop policy if exists offer_insert on offers;
drop policy if exists offer_update on offers;
create policy offer_read on offers for select to authenticated using (
  owner = auth.uid() or public.is_admin() or exists (
    select 1 from requests r where r.id = offers.request_id and r.owner = auth.uid())
);
create policy offer_insert on offers for insert to authenticated with check (
  owner = auth.uid() and exists (
    select 1 from shops s where s.id = shop_id and s.owner = auth.uid()
      and s.approved and s.paid_until > now())
);
create policy offer_update on offers for update to authenticated
  using (owner = auth.uid())
  with check (owner = auth.uid() and exists (
    select 1 from shops s where s.id = shop_id and s.owner = auth.uid()
      and s.approved and s.paid_until > now()));

-- الإعدادات: الكل يقرأ، الإدارة فقط تعدّل
drop policy if exists settings_read on settings;
drop policy if exists settings_write on settings;
create policy settings_read on settings for select to authenticated using (true);
create policy settings_write on settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- حسابات الإدارة: كل واحد يشوف نفسه فقط
drop policy if exists admins_self on admins;
create policy admins_self on admins for select to authenticated using (user_id = auth.uid());

-- 4ب) البلاغات (إبلاغ المستخدمين عن طلب أو محل مخالف) ---------
create table if not exists reports (
  id bigint generated always as identity primary key,
  owner uuid not null default auth.uid(),
  target_type text not null check (target_type in ('request','shop','offer')),
  target_id bigint not null,
  reason text not null check (char_length(reason) between 2 and 300),
  status text not null default 'new' check (status in ('new','done')),
  created_at timestamptz not null default now()
);
alter table reports enable row level security;
grant select, insert, update, delete on table public.reports to authenticated;
grant usage, select on all sequences in schema public to authenticated;
drop policy if exists reports_insert on reports;
drop policy if exists reports_admin on reports;
create policy reports_insert on reports for insert to authenticated with check (owner = auth.uid());
create policy reports_admin on reports for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- 5) تعيين حساب الإدارة (شغّله بعد ما تنشئ المستخدم من Authentication → Users) ---
-- بدّل الإيميل بإيميل الإدارة وشغّل السطر التالي في استعلام منفصل:
--   insert into admins (user_id) select id from auth.users where email = 'ضع-إيميلك-هنا';
